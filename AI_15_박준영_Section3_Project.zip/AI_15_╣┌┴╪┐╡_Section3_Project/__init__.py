import flask
from flask import Flask, request, render_template
import numpy as np
from sklearn import *
import json
import pickle

model = None
with open("/Users/JunPark/Section3/Project/ml/model.pkl",'rb') as pickle_file:
   model = pickle.load(pickle_file)

app = Flask(__name__)

@app.route("/")
@app.route("/index")
def index():
    return flask.render_template('index.html')

@app.route('/predict', methods=['POST'])
def home():
    Diet_type = request.form['Diet_type']
    Cuisine_type = request.form['Cuisine_type']
    Carbs_ratio = request.form['Carbs_ratio']
    Protein_ratio = request.form['Protein_ratio']
    Fat_ratio = request.form['Fat_ratio']
    
    arr = np.array([[Diet_type, Cuisine_type, Carbs_ratio, Protein_ratio, Fat_ratio]])
    pred = model.predict(arr)
    # 보여줄 페이지 그리고 어떤 데이터를 넘길지에 대해서 확인한다....
    # 모델이 예측한 결과를 넘겨서 그 값에 따라 if문을 작성하게 한다.
    return render_template('predict.html', data=pred)

if __name__ == "__main__":
    app.run(debug=True)
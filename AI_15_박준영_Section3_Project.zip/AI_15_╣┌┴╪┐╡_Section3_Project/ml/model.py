import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from category_encoders import OrdinalEncoder
from sklearn.svm import SVC
from pandas import MultiIndex, Int16Dtype
from sklearn import *

df = pd.read_csv("C:/Users/JunPark/Section3/Project/recipes_data.csv")

target = 'Recipe_name'

y = df[target]
X = df.drop(target, axis=1)

X_train, X_test, y_train, y_test = train_test_split(X, y,  random_state=42, test_size=0.3, shuffle=True)

ode = OrdinalEncoder()

X_train_ode = ode.fit_transform(X_train)
X_test_ode = ode.transform(X_test)

sv = SVC()

sv.fit(X_train_ode, y_train)

pred = sv.predict(X_test_ode)

import pickle

with open('model.pkl','wb') as pickle_file:
    pickle.dump(sv, pickle_file)